# ちいさななかまたち — projet Android

Ce dossier est un **projet Android Studio**, pas un APK déjà compilé.

## Compilation sur ordinateur (Windows, macOS ou Linux)
1. Installer Android Studio (https://developer.android.com/studio).
2. Décompresser ce ZIP, puis dans Android Studio choisir **Open / Ouvrir** et sélectionner le dossier `Chisana_Nakama_Android_Studio`.
3. Accepter l'installation des composants SDK demandés et attendre la synchronisation Gradle (connexion Internet requise lors du premier lancement).
4. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Cliquer sur **locate** dans la notification ou récupérer `app/build/outputs/apk/debug/app-debug.apk`.
6. Transférer cet APK sur le téléphone Android, puis l'ouvrir. Android peut demander l'autorisation d'installer une application provenant de cette source. Ne distribuer que des APK compilés par une personne de confiance.

## Sauvegardes et mises à jour
- La sauvegarde du jeu est propre à l'application, distincte de celle de Chrome.
- Dans Chrome : utiliser **Sauvegarder** pour exporter le JSON.
- Dans l'APK : utiliser **Restaurer** pour sélectionner ce JSON.
- Dans l'APK : **Sauvegarder** ouvre le sélecteur Android « Enregistrer sous ».
- Pour conserver la progression lors des futures mises à jour, conserver `applicationId` et signer les versions de publication avec **la même clé**.
- Un APK de debug est adapté aux essais; pour publier une version définitive, générer un APK de release signé dans Android Studio (Build > Generate Signed Bundle / APK).

## Fonctionnement
- HTML/CSS/JS original de la version V3 validée, intégré comme ressource locale.
- Pas de permission Internet; le jeu fonctionne hors ligne.
- Le temps écoulé est recalculé à la réouverture, comme dans la version navigateur.
- Android WebView nécessite Android 8.0+ (minSdk 26).
- La version Java du projet utilise Gradle/Android Gradle Plugin 8.5.2 et Java 17.
- Pas de compilation APK effectuée ici : il faut tester sur un appareil Android réel.

## Sécurité
- La sauvegarde JSON reste un fichier personnel; ne pas publier une sauvegarde privée avec le jeu.
- Le pont JavaScript n'accepte que l'export de sauvegardes courtes; aucune permission réseau n'est déclarée.

## Correctif de compatibilité V2
Cette édition cible Android 14 (targetSdk 34) au lieu d’Android 9 (targetSdk 28), pour éviter le blocage Play Protect relatif à l’ancien niveau de cible. Cela ne garantit pas l’absence d’autres avertissements de sécurité. Ne pas désactiver Play Protect. Le code de l’application reste le même, sans permission Internet.
