package org.chisananakama.game;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.*;
import android.widget.Toast;
import android.graphics.Color;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import java.io.OutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int PICK_JSON=1001, SAVE_JSON=1002;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingSave;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(11,11,24));
        getWindow().setNavigationBarColor(Color.rgb(11,11,24));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(11,11,24));
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new SaveBridge(), "ChisanaAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return true; // No external navigation or network access.
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if(fileCallback!=null)fileCallback.onReceiveValue(null);
                fileCallback=callback;
                Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/json","text/plain","application/octet-stream"});
                try { startActivityForResult(intent,PICK_JSON);return true; }
                catch(Exception e){fileCallback=null;callback.onReceiveValue(null);return false;}
            }
        });
        try(InputStream in=getAssets().open("index.html")) {
            byte[] bytes=new byte[in.available()];
            int pos=0,read;
            while(pos<bytes.length && (read=in.read(bytes,pos,bytes.length-pos))>0)pos+=read;
            String html=new String(bytes,0,pos,StandardCharsets.UTF_8);
            // Stable secure origin for localStorage, with no remote fetches.
            webView.loadDataWithBaseURL("https://appassets.androidplatform.net/",html,"text/html","UTF-8",null);
        }catch(Exception e){Toast.makeText(this,"Erreur de chargement du jeu",Toast.LENGTH_LONG).show();}
    }

    private class SaveBridge {
        @JavascriptInterface public void exportSave(String json) {
            if(json==null || json.length()>100000)return;
            runOnUiThread(()->{
                pendingSave=json;
                Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE,"Chisana_Nakama_Sauvegarde.json");
                try{startActivityForResult(intent,SAVE_JSON);}
                catch(Exception e){pendingSave=null;Toast.makeText(MainActivity.this,"Export impossible",Toast.LENGTH_LONG).show();}
            });
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_JSON){
            if(fileCallback!=null){
                Uri[] uris=(resultCode==RESULT_OK && data!=null && data.getData()!=null)
                    ?new Uri[]{data.getData()}:null;
                fileCallback.onReceiveValue(uris);
                fileCallback=null;
            }
        }else if(requestCode==SAVE_JSON){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null && pendingSave!=null){
                try(OutputStream out=getContentResolver().openOutputStream(data.getData())){
                    if(out==null)throw new Exception("Flux indisponible");
                    out.write(pendingSave.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this,"Sauvegarde enregistrée 💜",Toast.LENGTH_LONG).show();
                }catch(Exception e){Toast.makeText(this,"Erreur d'enregistrement",Toast.LENGTH_LONG).show();}
            }
            pendingSave=null;
        }
    }
    @Override protected void onPause(){webView.evaluateJavascript("document.dispatchEvent(new Event('visibilitychange'));",null);super.onPause();}
    @Override protected void onDestroy(){if(fileCallback!=null)fileCallback.onReceiveValue(null);webView.destroy();super.onDestroy();}
}
